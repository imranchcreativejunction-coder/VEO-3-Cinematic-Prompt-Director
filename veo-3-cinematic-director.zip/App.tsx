
import React, { useState, useCallback } from 'react';
import type { CreationMode, BrainstormAnswers, SubmitPayload } from './types';
import LandingScreen from './components/LandingScreen';
import InputScreen from './components/InputScreen';
import OutputScreen from './components/OutputScreen';
import { generateJsonPrompt, generateCinematicDescription } from './services/geminiService';

type AppStep = 'landing' | 'input' | 'output';

const App: React.FC = () => {
    const [step, setStep] = useState<AppStep>('landing');
    const [mode, setMode] = useState<CreationMode | null>(null);
    const [isLoading, setIsLoading] = useState<boolean>(false);
    const [error, setError] = useState<string | null>(null);
    const [generatedJson, setGeneratedJson] = useState<string>('');
    const [cinematicDescription, setCinematicDescription] = useState<string>('');

    const handleModeSelect = (selectedMode: CreationMode) => {
        setMode(selectedMode);
        setStep('input');
    };

    const handleBack = () => {
        setStep('landing');
        setMode(null);
        setError(null);
        setGeneratedJson('');
        setCinematicDescription('');
    };
    
    const handleStartOver = () => {
        setStep('landing');
        setMode(null);
        setError(null);
        setGeneratedJson('');
        setCinematicDescription('');
        setIsLoading(false);
    }

    const handleSubmit = useCallback(async ({ data, isFinalPrompt = false }: SubmitPayload) => {
        if (!mode) return;
        
        setIsLoading(true);
        setError(null);
        setGeneratedJson('');
        setCinematicDescription('');
        setStep('output');

        try {
            const jsonOutput = await generateJsonPrompt(data, mode, isFinalPrompt);
            setGeneratedJson(jsonOutput);

            const description = await generateCinematicDescription(jsonOutput);
            setCinematicDescription(description);
        } catch (e) {
            console.error(e);
            setError('An error occurred during generation. Please check the console for details and try again.');
        } finally {
            setIsLoading(false);
        }
    }, [mode]);

    const renderContent = () => {
        switch (step) {
            case 'landing':
                return <LandingScreen onModeSelect={handleModeSelect} />;
            case 'input':
                return mode && <InputScreen mode={mode} onBack={handleBack} onSubmit={handleSubmit} />;
            case 'output':
                return <OutputScreen
                    isLoading={isLoading}
                    jsonPrompt={generatedJson}
                    cinematicDescription={cinematicDescription}
                    error={error}
                    onStartOver={handleStartOver}
                />;
            default:
                return <LandingScreen onModeSelect={handleModeSelect} />;
        }
    };

    return (
        <div className="min-h-screen bg-brand-bg font-sans flex flex-col items-center justify-center p-4 selection:bg-brand-primary selection:text-white">
            <div className="w-full max-w-5xl mx-auto">
                {renderContent()}
            </div>
        </div>
    );
};

export default App;