
import { GoogleGenAI, Type } from "@google/genai";
import type { CreationMode, BrainstormAnswers } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

const VEO_PROMPT_SCHEMA = {
    type: Type.OBJECT,
    properties: {
        "Scene 1": {
            type: Type.OBJECT,
            properties: {
                title: { type: Type.STRING, description: "A short, cinematic, and context-appropriate title for the scene." },
                scene: {
                    type: Type.OBJECT,
                    properties: {
                        camera: {
                            type: Type.OBJECT,
                            properties: {
                                type: { type: Type.STRING },
                                angle: { type: Type.STRING },
                                motion: { type: Type.STRING },
                                focus: { type: Type.STRING }
                            },
                            required: ["type", "angle", "motion", "focus"]
                        },
                        subject: {
                            type: Type.OBJECT,
                            properties: {
                                character: { type: Type.STRING },
                                appearance: { type: Type.STRING },
                                expression: { type: Type.STRING },
                                accessories: { type: Type.STRING }
                            },
                             required: ["character", "appearance", "expression"]
                        },
                        props: {
                            type: Type.OBJECT,
                            properties: {
                                main_props: { type: Type.STRING },
                                secondary_props: { type: Type.STRING },
                                environment_props: { type: Type.STRING }
                            },
                            required: ["main_props"]
                        },
                        setting: {
                            type: Type.OBJECT,
                            properties: {
                                location: { type: Type.STRING },
                                time: { type: Type.STRING },
                                background: { type: Type.STRING },
                                atmosphere: { type: Type.STRING }
                            },
                            required: ["location", "time", "atmosphere"]
                        },
                        lighting: {
                            type: Type.OBJECT,
                            properties: {
                                style: { type: Type.STRING },
                                mood: { type: Type.STRING },
                                shadows: { type: Type.STRING }
                            },
                             required: ["style", "mood"]
                        }
                    },
                    required: ["camera", "subject", "props", "setting", "lighting"]
                },
                action: {
                    type: Type.OBJECT,
                    properties: {
                        primary_action: { type: Type.STRING },
                        secondary_actions: { type: Type.STRING },
                        interaction: { type: Type.STRING },
                        timing: { type: Type.STRING, description: "Must strictly follow 0-2s setup, 2-6s main action, 6-8s conclusion structure for an 8-second duration." },
                        pacing: { type: Type.STRING }
                    },
                    required: ["primary_action", "timing", "pacing"]
                },
                dialogue: {
                    type: Type.OBJECT,
                    properties: {
                        speech: { type: Type.STRING, description: "Must be 1-2 short sentences, no ALL CAPS." },
                        tone: { type: Type.STRING },
                        lip_sync: { type: Type.STRING },
                        no_subtitles: { type: Type.BOOLEAN },
                        no_captions: { type: Type.BOOLEAN },
                        no_text_overlay: { type: Type.BOOLEAN }
                    },
                    required: ["speech", "tone", "no_subtitles", "no_captions", "no_text_overlay"]
                },
                audio: {
                    type: Type.OBJECT,
                    properties: {
                        voice: { type: Type.STRING },
                        action_sounds: { type: Type.STRING },
                        environmental: { type: Type.STRING },
                        music: { type: Type.STRING },
                        ambience: { type: Type.STRING }
                    },
                    required: ["voice", "action_sounds", "environmental"]
                },
                style: {
                    type: Type.OBJECT,
                    properties: {
                        genre: { type: Type.STRING },
                        mood: { type: Type.STRING },
                        visual_style: { type: Type.STRING },
                        pacing: { type: Type.STRING }
                    },
                    required: ["genre", "mood", "visual_style"]
                },
                no_subtitles: { type: Type.BOOLEAN },
                no_captions: { type: Type.BOOLEAN },
                no_text_overlay: { type: Type.BOOLEAN }
            },
             required: ["title", "scene", "action", "dialogue", "audio", "style", "no_subtitles", "no_captions", "no_text_overlay"]
        }
    },
    required: ["Scene 1"]
};

const getSystemInstruction = () => {
    return `You are an award-winning Veo 3 cinematic director and Universal JSON Meta-Prompt Generator. Your job is to take user input and expand it into a professional Veo 3 JSON prompt.
    
MANDATORY RULES:
- You MUST generate a short, cinematic title for the scene and place it in the 'title' field.
- You MUST generate a complete JSON object that strictly follows the provided schema.
- Maintain exact scene consistency for multi-scene prompts (character, appearance, setting, etc. stay the same).
- Dialogue MUST be 1-2 short sentences.
- Dialogue MUST NOT use ALL CAPS.
- Every scene MUST include 'no_subtitles', 'no_captions', and 'no_text_overlay' flags set to true, both in the root of the scene object and within the dialogue object.
- The action timing structure MUST strictly adhere to: 0-2s setup, 2-6s main action, 6-8s conclusion for an 8-second total duration.
- Fill every single field in the JSON with vivid, cinematic, and director-level details. Be highly descriptive and creative.
- Do not add any commentary or explanation outside of the JSON object itself.
`;
};

const buildPromptFromInput = (userInput: string | BrainstormAnswers, mode: CreationMode): string => {
    if (typeof userInput === 'string') {
        switch (mode) {
            case 'vague':
                return `Expand this vague idea into a full cinematic scene: "${userInput}"`;
            case 'preset':
                return `Create a scene based on this preset style: "${userInput}"`;
            case 'library':
                return `Generate a JSON prompt for this idea from the library: "${userInput}"`;
            default:
                return userInput;
        }
    } else { // BrainstormAnswers
        return `Brainstorm and create a complete scene based on these user answers:
        - Domain/Industry: ${userInput.domain}
        - Main Character/Subject: ${userInput.character}
        - Setting/Environment: ${userInput.setting}
        - Mood/Tone: ${userInput.mood}
        - Key Props/Features: ${userInput.features}`;
    }
};


export const generateJsonPrompt = async (userInput: string | BrainstormAnswers, mode: CreationMode, isFinalPrompt = false): Promise<string> => {
    const userPrompt = isFinalPrompt && typeof userInput === 'string'
        ? userInput
        : buildPromptFromInput(userInput, mode);

    const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: userPrompt,
        config: {
            systemInstruction: getSystemInstruction(),
            responseMimeType: "application/json",
            responseSchema: VEO_PROMPT_SCHEMA,
        },
    });

    const jsonText = response.text.trim();
    // Gemini with JSON schema often returns a clean object, but let's format it for display
    try {
        const parsedJson = JSON.parse(jsonText);
        return JSON.stringify(parsedJson, null, 2);
    } catch (e) {
        console.error("Failed to parse JSON from Gemini, returning raw text.", e);
        return jsonText; // Return raw text if parsing fails
    }
};

export const generateCinematicDescription = async (jsonPrompt: string): Promise<string> => {
    const systemInstruction = `You are a world-class cinematic director and a vivid writer. Your task is to take a structured JSON scene prompt and expand it into a rich, detailed, and evocative cinematic description. The description MUST be under 950 characters. It should be written in beautiful prose, as if you are describing the scene to your production crew. It must be detailed enough for a director of photography, sound designer, and actor to understand the complete vision.

    Breakdown your description into logical sections based on the JSON structure (e.g., Setting the Scene, The Subject, Camera & Movement, The Action Unfolds, Soundscape & Mood). Include all key elements from the JSON, but expand upon them with sensory details, emotional depth, and cinematic flair.`;

    const userPrompt = `Here is the JSON prompt. Please expand it into a full cinematic description that is under 950 characters, following your instructions.

JSON Prompt:
\`\`\`json
${jsonPrompt}
\`\`\`
`;
    
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: userPrompt,
        config: {
            systemInstruction: systemInstruction,
        },
    });

    return response.text;
};