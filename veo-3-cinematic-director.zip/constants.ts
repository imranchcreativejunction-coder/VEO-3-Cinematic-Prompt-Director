import type { Idea, PresetStyleSchema } from './types';

export const PRESET_STYLE_SCHEMA: PresetStyleSchema = {
    "category": [
      "Cinematic Films",
      "Emotional TVC",
      "Comedy Skit",
      "Lifestyle Vlog",
      "Product Demo",
      "ASMR Visual",
      "Surreal Dreamscape",
      "Historical Reenactment",
      "Miniature Diorama",
      "Claymation",
      "Pencil Sketch",
      "Watercolor Motion",
      "Stop-Motion",
      "Stickman Animatic",
      "Kids' Illustrated Story",
      "Noir Detective",
      "Retro VHS",
      "Cyberpunk",
      "Fantasy Epic",
      "Mixed-Media Collage",
      "Cinematic Ad"
    ],
    "visual_style": [
      "Default",
      "Cinematic 35mm Film",
      "Documentary Realism",
      "Surreal Pastel",
      "Monochrome Noir",
      "Minimalist Pastel",
      "Clay Animation",
      "Hand-drawn Pencil",
      "Watercolor Ink",
      "Stop-Motion Handmade",
      "Storybook Illustration",
      "Retro VHS Grain",
      "Neon Cyberpunk",
      "Fantasy Matte Painting",
      "Mixed-Media Collage"
    ],
    "tone_mood": [
      "Default",
      "Inspirational",
      "Emotional",
      "Humorous",
      "Mystical",
      "Playful",
      "Epic",
      "Relaxing",
      "Intense",
      "Poetic",
      "Suspenseful"
    ],
    "camera_style": [
      "Default",
      "Handheld",
      "Steady-Cam",
      "POV",
      "Wide-Angle",
      "Close-Up / Macro",
      "Tracking Shot",
      "Drone / Aerial",
      "Stop-Motion Frame"
    ],
    "lighting_style": [
      "Default",
      "Golden Hour Cinematic",
      "High Contrast Noir",
      "Soft Diffused Glow",
      "Moody Shadows",
      "Neon Glow",
      "Candlelit Warmth",
      "Overexposed Surreal"
    ],
    "audio_style": [
      "Default",
      "Natural Ambient",
      "Cinematic Score",
      "Whispered Voice",
      "Narrative Storytelling",
      "Playful Dialogue",
      "Silent (Visual Only)"
    ],
    "voice_quality": [
      "Default",
      "Human Deep Cinematic Male",
      "Human Gentle Cinematic Female",
      "Human Whispered Intimate",
      "Human Storytelling Narrator",
      "Human Playful Tone",
      "Human Emotional Heartfelt"
    ]
};

export const BRAINSTORM_QUESTIONS = [
    "What's your domain or industry? (e.g., food, fitness, cryptid vlogging, ASMR)",
    "Who is your main character or subject?",
    "What's the primary setting or environment?",
    "What's the overall mood and tone? (e.g., mysterious and tense, calm and hopeful)",
    "Any key props, actions, or special features to include?"
];

export const IDEA_LIBRARY_ITEMS: Idea[] = [
    {
        title: "Desert Dawn",
        description: "A cinematic shot of a lone wanderer crossing a vast desert at dawn.",
        prompt: "A lone wanderer walks across a desert at dawn, dust swirling around boots."
    },
    {
        title: "Attic Memories",
        description: "An emotional scene where a child discovers their family's past through an old camera.",
        prompt: "A child finds an old camera in the attic and sees their grandparents’ wedding footage."
    },
    {
        title: "The Grumpy Sandwich",
        description: "A funny skit featuring a talking sandwich complaining to its creator, the chef.",
        prompt: "Talking sandwich argues with chef about seasoning."
    },
    {
        title: "Tokyo Rain Cafe",
        description: "A lifestyle vlog capturing the cozy, rainy atmosphere of a Tokyo coffee shop.",
        prompt: "A traveler captures a cozy coffee shop in Tokyo, rainy window in background."
    },
    {
        title: "Golden Hour Timepiece",
        description: "A sleek product demo of a luxury watch, highlighting its details in the golden hour light.",
        prompt: "Luxury wristwatch catches golden sunset light as water droplets slide down crystal."
    },
    {
        title: "Honey Drip ASMR",
        description: "A satisfying and calming close-up ASMR visual of honey dripping.",
        prompt: "Close-up of glowing honey slowly dripping on rough wooden surface."
    },
    {
        title: "Stairway to the Moon",
        description: "A surreal dreamscape featuring a cloud staircase ascending to a glowing moon gate.",
        prompt: "Floating staircase made of clouds leads to glowing moon gate."
    },
    {
        title: "The Scribe's Scroll",
        description: "A historical reenactment of a scribe at work by candlelight, writing on ancient scrolls.",
        prompt: "A scribe dips feather pen into ink, candlelight flickering across ancient scrolls."
    },
    {
        title: "Miniature Market",
        description: "A vibrant miniature diorama shot of a bustling street market with tiny vendors.",
        prompt: "Tiny street market alive with toy vendors and moving lights."
    },
    {
        title: "Clumsy Clay Baker",
        description: "A charming claymation scene of a robot comically failing at baking bread.",
        prompt: "A clay robot bakes bread but keeps squishing the dough in funny shapes."
    },
    {
        title: "Animated Dragon Sketch",
        description: "A pencil sketch of a dragon comes to life as it's being drawn.",
        prompt: "Hand draws a dragon mid-flight; wings animate as pencil moves."
    },
    {
        title: "Blooming Watercolors",
        description: "Beautiful watercolor flowers bloom on paper with a mesmerizing ripple effect.",
        prompt: "Painted flowers bloom in slow ripple effect, watercolor spreading across paper."
    },
    {
        title: "Magic Library",
        description: "A stop-motion animation where old books magically arrange themselves into a castle.",
        prompt: "Old books shuffle on their own to form a castle shape."
    },
    {
        title: "The Determined Climber",
        description: "A simple but engaging stickman animatic of a climber battling the elements.",
        prompt: "Stickman attempts to climb a mountain; wind keeps blowing him back."
    },
    {
        title: "The Flying Fox",
        description: "A whimsical kids' story illustration of a rainbow fox flying over a candy forest.",
        prompt: "Rainbow fox learns to fly on giant bubble over candy forest."
    }
];