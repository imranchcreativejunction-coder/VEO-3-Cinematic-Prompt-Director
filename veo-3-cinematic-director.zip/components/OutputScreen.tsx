
import React, { useState } from 'react';
import Card from './ui/Card';
import Button from './ui/Button';
import Loader from './ui/Loader';

interface OutputScreenProps {
    isLoading: boolean;
    jsonPrompt: string;
    cinematicDescription: string;
    error: string | null;
    onStartOver: () => void;
}

const OutputScreen: React.FC<OutputScreenProps> = ({ isLoading, jsonPrompt, cinematicDescription, error, onStartOver }) => {
    const [jsonCopied, setJsonCopied] = useState(false);
    const [descCopied, setDescCopied] = useState(false);

    const handleCopy = (text: string, type: 'json' | 'desc') => {
        navigator.clipboard.writeText(text);
        if (type === 'json') {
            setJsonCopied(true);
            setTimeout(() => setJsonCopied(false), 2000);
        } else {
            setDescCopied(true);
            setTimeout(() => setDescCopied(false), 2000);
        }
    };

    const handleDownloadJson = () => {
        const blob = new Blob([jsonPrompt], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'veo3_prompt.json';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
    };

    if (isLoading) {
        return <Card className="!p-8 text-center"><Loader text="Directing the perfect shot..." /></Card>;
    }
    
    if (error) {
        return (
            <Card className="!p-8 text-center">
                <h2 className="text-2xl font-bold text-red-500 mb-4">An Error Occurred</h2>
                <p className="text-brand-text-muted mb-6">{error}</p>
                <Button onClick={onStartOver} variant="secondary">Try Again</Button>
            </Card>
        );
    }

    return (
        <div className="space-y-8">
            {jsonPrompt && (
                <Card>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-semibold">Generated Veo 3 JSON Prompt</h2>
                        <div className="flex gap-2">
                            <Button onClick={() => handleCopy(jsonPrompt, 'json')} variant="outline" size-sm>{jsonCopied ? 'Copied!' : 'Copy'}</Button>
                            <Button onClick={handleDownloadJson} variant="outline" size-sm>Download</Button>
                        </div>
                    </div>
                    <pre className="bg-brand-bg p-4 rounded-lg overflow-x-auto text-sm max-h-[500px]">
                        <code>{jsonPrompt}</code>
                    </pre>
                </Card>
            )}

            {cinematicDescription && (
                 <Card>
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="text-2xl font-semibold">Cinematic Description</h2>
                         <Button onClick={() => handleCopy(cinematicDescription, 'desc')} variant="outline" size-sm>{descCopied ? 'Copied!' : 'Copy'}</Button>
                    </div>
                    <div className="bg-brand-bg p-4 rounded-lg prose prose-invert prose-p:text-brand-text-muted max-w-none max-h-[400px] overflow-y-auto">
                        {cinematicDescription.split('\n').map((paragraph, index) => (
                           <p key={index}>{paragraph}</p> 
                        ))}
                    </div>
                </Card>
            )}
            
            <div className="text-center mt-8">
                <Button onClick={onStartOver} variant="primary">Start a New Scene</Button>
            </div>
        </div>
    );
};

export default OutputScreen;