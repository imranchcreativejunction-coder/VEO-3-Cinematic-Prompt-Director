import React from 'react';
import type { CreationMode } from '../types';
import Card from './ui/Card';

interface LandingScreenProps {
    onModeSelect: (mode: CreationMode) => void;
}

const options = [
    { 
        mode: 'vague' as CreationMode,
        icon: 'M15.042 21.672 13.684 16.6m0 0-2.51 2.225.569-9.47 5.227 7.917-3.286-.672ZM12 2.25V4.5m5.834.166-1.591 1.591M21.75 12h-2.25m.166 5.834-1.591-1.591M12 21.75v-2.25m-5.834-.166 1.591-1.591M2.25 12h2.25m-.166-5.834 1.591 1.591',
        title: 'Start with a Vague Idea',
        description: 'Have a spark of a concept? Enter a short idea and let the AI director flesh it out.' 
    },
    { 
        mode: 'preset' as CreationMode,
        icon: 'M3.75 6A2.25 2.25 0 0 1 6 3.75h2.25A2.25 2.25 0 0 1 10.5 6v2.25a2.25 2.25 0 0 1-2.25 2.25H6a2.25 2.25 0 0 1-2.25-2.25V6ZM3.75 15.75A2.25 2.25 0 0 1 6 13.5h2.25a2.25 2.25 0 0 1 2.25 2.25V18a2.25 2.25 0 0 1-2.25 2.25H6A2.25 2.25 0 0 1 3.75 18v-2.25ZM13.5 6a2.25 2.25 0 0 1 2.25-2.25H18A2.25 2.25 0 0 1 20.25 6v2.25A2.25 2.25 0 0 1 18 10.5h-2.25a2.25 2.25 0 0 1-2.25-2.25V6ZM13.5 15.75a2.25 2.25 0 0 1 2.25-2.25H18a2.25 2.25 0 0 1 2.25 2.25V18A2.25 2.25 0 0 1 18 20.25h-2.25A2.25 2.25 0 0 1 13.5 18v-2.25Z',
        title: 'Choose a Preset Style',
        description: 'Pick from cinematic genres, moods, and niches to generate a prompt that fits a specific style.' 
    },
    { 
        mode: 'brainstorm' as CreationMode,
        icon: 'M12 18.75a6 6 0 0 0 6-6v-1.5m-6 7.5a6 6 0 0 1-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 0 1-3-3V4.5a3 3 0 0 1 6 0v8.25a3 3 0 0 1-3 3Z',
        title: 'Brainstorm from Scratch',
        description: 'Let the AI guide you through structured questions to build your concept from the ground up.' 
    },
    { 
        mode: 'library' as CreationMode,
        icon: 'M12 6.042A8.967 8.967 0 0 0 6 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 0 1 6 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 0 1 6-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0 0 18 18c-2.305 0-4.408.867-6 2.292m0-14.25v14.25',
        title: 'Use the Idea Library',
        description: 'Explore a curated library of high-performing ad and video prompts to kickstart your project.' 
    },
];

const LandingScreen: React.FC<LandingScreenProps> = ({ onModeSelect }) => {
    return (
        <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold mb-2">
                Veo 3 <span className="text-brand-primary">Cinematic Director</span>
            </h1>
            <p className="text-lg text-brand-text-muted mb-12">
                Hi! I’m your Veo 3 Director. Start with a vague idea, preset style, brainstorming session, or pick from idea library?
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {options.map((opt) => (
                    <Card key={opt.mode} onClick={() => onModeSelect(opt.mode)} className="text-left">
                        <div className="flex items-start gap-4">
                            <div className="mt-1 p-2 rounded-full bg-brand-primary/10 text-brand-primary">
                                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6">
                                    <path strokeLinecap="round" strokeLinejoin="round" d={opt.icon} />
                                </svg>
                            </div>
                            <div>
                                <h3 className="text-xl font-semibold text-brand-text">{opt.title}</h3>
                                <p className="text-brand-text-muted mt-1">{opt.description}</p>
                            </div>
                        </div>
                    </Card>
                ))}
            </div>
        </div>
    );
};

export default LandingScreen;
