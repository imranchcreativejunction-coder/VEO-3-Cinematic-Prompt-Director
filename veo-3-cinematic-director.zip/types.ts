export type CreationMode = 'vague' | 'preset' | 'brainstorm' | 'library';

export interface BrainstormAnswers {
    domain: string;
    character: string;
    setting: string;
    mood: string;
    features: string;
}

export interface SubmitPayload {
    data: string | BrainstormAnswers;
    isFinalPrompt?: boolean;
}

export interface Idea {
    title: string;
    description: string;
    prompt: string;
}

export type PresetStyleSchema = {
    category: string[];
    visual_style: string[];
    tone_mood: string[];
    camera_style: string[];
    lighting_style: string[];
    audio_style: string[];
    voice_quality: string[];
};

export type PresetSelection = {
    [K in keyof PresetStyleSchema]: string;
};