
import React from 'react';

interface CardProps {
    children: React.ReactNode;
    className?: string;
    onClick?: () => void;
}

const Card: React.FC<CardProps> = ({ children, className = '', onClick }) => {
    const hoverClasses = onClick ? 'hover:bg-opacity-80 hover:border-brand-primary cursor-pointer' : '';

    return (
        <div 
            className={`bg-brand-surface border border-gray-700 rounded-xl p-6 transition-all duration-300 ${hoverClasses} ${className}`}
            onClick={onClick}
        >
            {children}
        </div>
    );
};

export default Card;
