
import React, { useState } from 'react';
import type { CreationMode, BrainstormAnswers, PresetSelection, PresetStyleSchema, SubmitPayload } from '../types';
import { PRESET_STYLE_SCHEMA, BRAINSTORM_QUESTIONS, IDEA_LIBRARY_ITEMS } from '../constants';
import Button from './ui/Button';
import Card from './ui/Card';

interface InputScreenProps {
    mode: CreationMode;
    onBack: () => void;
    onSubmit: (payload: SubmitPayload) => void;
}

const InputScreen: React.FC<InputScreenProps> = ({ mode, onBack, onSubmit }) => {
    const [vagueIdea, setVagueIdea] = useState('');
    const [adIdea, setAdIdea] = useState('');
    
    const [presetSelections, setPresetSelections] = useState<PresetSelection>({
        category: PRESET_STYLE_SCHEMA.category[0],
        visual_style: PRESET_STYLE_SCHEMA.visual_style[0],
        tone_mood: PRESET_STYLE_SCHEMA.tone_mood[0],
        camera_style: PRESET_STYLE_SCHEMA.camera_style[0],
        lighting_style: PRESET_STYLE_SCHEMA.lighting_style[0],
        audio_style: PRESET_STYLE_SCHEMA.audio_style[0],
        voice_quality: PRESET_STYLE_SCHEMA.voice_quality[0],
    });

    const [brainstormStep, setBrainstormStep] = useState(0);
    const [brainstormAnswers, setBrainstormAnswers] = useState<BrainstormAnswers>({ domain: '', character: '', setting: '', mood: '', features: '' });
    const [currentAnswer, setCurrentAnswer] = useState('');
    const [selectedIdea, setSelectedIdea] = useState<string>('');

    const [editablePrompt, setEditablePrompt] = useState<string | null>(null);

    const handlePresetChange = (field: keyof PresetSelection, value: string) => {
        setPresetSelections(prev => ({ ...prev, [field]: value }));
    };

    const handleNextBrainstorm = () => {
        const currentKey = Object.keys(brainstormAnswers)[brainstormStep] as keyof BrainstormAnswers;
        const newAnswers = { ...brainstormAnswers, [currentKey]: currentAnswer };

        if (brainstormStep < BRAINSTORM_QUESTIONS.length - 1) {
             setBrainstormAnswers(newAnswers);
             setCurrentAnswer('');
            setBrainstormStep(prev => prev + 1);
        } else {
             // On the last question, generate the prompt and show the preview
            const finalPrompt = `Brainstorm and create a complete scene based on these user answers:
- Domain/Industry: ${newAnswers.domain}
- Main Character/Subject: ${newAnswers.character}
- Setting/Environment: ${newAnswers.setting}
- Mood/Tone: ${newAnswers.mood}
- Key Props/Features: ${newAnswers.features}`;
            setEditablePrompt(finalPrompt);
        }
    };

    const handleGenerateClick = () => {
        switch (mode) {
            case 'vague':
                if (vagueIdea) {
                    const finalPrompt = `Expand this vague idea into a full cinematic scene: "${vagueIdea}"`;
                    setEditablePrompt(finalPrompt);
                }
                break;
            case 'preset': {
                let innerPrompt = 'Generate a scene based on the following preset style attributes:\n';
                if (presetSelections.category === 'Cinematic Ad' && adIdea) {
                    innerPrompt = `Generate a scene for a cinematic ad about: "${adIdea}".\nUse the following preset style attributes:\n`;
                }

                const activeSelections = (Object.keys(presetSelections) as Array<keyof PresetSelection>)
                    .filter(key => key === 'category' || presetSelections[key] !== 'Default');
                
                const submissionPromptLines = activeSelections.map(key => {
                    const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                    return `${label}: ${presetSelections[key]}`;
                });
                const submissionData = `${innerPrompt}${submissionPromptLines.join('\n')}`.trim();

                const finalPrompt = `Create a scene based on this preset style: "${submissionData}"`;
                setEditablePrompt(finalPrompt);
                break;
            }
            case 'library':
                if (selectedIdea) {
                    const finalPrompt = `Generate a JSON prompt for this idea from the library: "${selectedIdea}"`;
                    setEditablePrompt(finalPrompt);
                }
                break;
        }
    };
    
    if (editablePrompt !== null) {
        return (
            <Card className="!p-8">
                <h2 className="text-2xl font-semibold mb-2">Edit & Confirm Prompt</h2>
                <p className="text-brand-text-muted mb-4">
                    You can make final adjustments to the prompt below before sending it to the AI Director.
                </p>
                <textarea
                    value={editablePrompt}
                    onChange={(e) => setEditablePrompt(e.target.value)}
                    className="w-full h-48 p-4 bg-brand-bg border border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:outline-none transition resize-y"
                    aria-label="Editable prompt text"
                />
                <div className="mt-8 flex justify-between items-center">
                    <Button onClick={() => setEditablePrompt(null)} variant="outline">
                        Back to Editing
                    </Button>
                    <Button onClick={() => onSubmit({ data: editablePrompt, isFinalPrompt: true })}>
                        Confirm & Generate JSON
                    </Button>
                </div>
            </Card>
        );
    }

    const renderForm = () => {
        switch (mode) {
            case 'vague':
                return (
                    <div>
                        <h2 className="text-2xl font-semibold mb-4">Describe Your Vague Idea</h2>
                        <textarea
                            value={vagueIdea}
                            onChange={(e) => setVagueIdea(e.target.value)}
                            placeholder="e.g., A forest creature making a vlog..."
                            className="w-full h-32 p-4 bg-brand-bg border border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:outline-none transition"
                        />
                    </div>
                );
            case 'preset':
                return (
                     <div>
                        <h2 className="text-2xl font-semibold mb-4">Build a Custom Preset Style</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                             {(Object.keys(PRESET_STYLE_SCHEMA) as Array<keyof PresetStyleSchema>).map(key => {
                                const label = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                                return (
                                    <div key={key}>
                                        <label htmlFor={key} className="block text-sm font-medium text-brand-text-muted mb-1">{label}</label>
                                        <select
                                            id={key}
                                            value={presetSelections[key]} 
                                            onChange={e => handlePresetChange(key, e.target.value)} 
                                            className="w-full p-3 bg-brand-surface border border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:outline-none transition"
                                        >
                                            {PRESET_STYLE_SCHEMA[key].map(option => <option key={option} value={option}>{option}</option>)}
                                        </select>
                                    </div>
                                );
                            })}
                        </div>
                        {presetSelections.category === 'Cinematic Ad' && (
                            <div className="mt-6">
                                <label htmlFor="adIdea" className="block text-lg font-medium text-brand-text mb-2">Product Name or Ad Idea</label>
                                <textarea
                                    id="adIdea"
                                    value={adIdea}
                                    onChange={(e) => setAdIdea(e.target.value)}
                                    placeholder="e.g., 'A sleek new electric car' or 'Quantum Cola'"
                                    className="w-full h-24 p-4 bg-brand-bg border border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:outline-none transition"
                                />
                            </div>
                        )}
                    </div>
                );
            case 'brainstorm':
                const isLastQuestion = brainstormStep === BRAINSTORM_QUESTIONS.length - 1;
                return (
                     <div>
                        <h2 className="text-2xl font-semibold mb-2">Brainstorm with the Director</h2>
                         <p className="text-brand-text-muted mb-6">{`Question ${brainstormStep + 1} of ${BRAINSTORM_QUESTIONS.length}`}</p>
                        <label className="block text-lg font-medium text-brand-text mb-4">{BRAINSTORM_QUESTIONS[brainstormStep]}</label>
                        <input
                            type="text"
                            value={currentAnswer}
                            onChange={(e) => setCurrentAnswer(e.target.value)}
                            onKeyDown={(e) => e.key === 'Enter' && currentAnswer && handleNextBrainstorm()}
                            className="w-full p-4 bg-brand-bg border border-gray-600 rounded-lg focus:ring-2 focus:ring-brand-primary focus:outline-none transition"
                            autoFocus
                        />
                         <div className="mt-4 text-right">
                             <Button onClick={handleNextBrainstorm} disabled={!currentAnswer}>
                                {isLastQuestion ? 'Preview Prompt' : 'Next Question'}
                            </Button>
                        </div>
                    </div>
                )
            case 'library':
                return (
                     <div>
                        <h2 className="text-2xl font-semibold mb-4">Choose from the Idea Library</h2>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 max-h-[400px] overflow-y-auto pr-2">
                             {IDEA_LIBRARY_ITEMS.map(idea => (
                                <Card 
                                    key={idea.title}
                                    onClick={() => setSelectedIdea(idea.prompt)}
                                    className={`!p-4 ${selectedIdea === idea.prompt ? 'ring-2 ring-brand-primary' : ''}`}
                                >
                                    <h3 className="font-semibold text-brand-text">{idea.title}</h3>
                                    <p className="text-sm text-brand-text-muted mt-1">{idea.description}</p>
                                </Card>
                            ))}
                        </div>
                    </div>
                );
        }
    };
    
    const isSubmitDisabled = () => {
        switch (mode) {
            case 'vague': 
                return !vagueIdea;
            case 'preset':
                if (presetSelections.category === 'Cinematic Ad') {
                    return !adIdea;
                }
                return false;
            case 'library': 
                return !selectedIdea;
            case 'brainstorm': 
                return true; // Handled by its own button
            default: 
                return false;
        }
    };

    return (
        <Card className="!p-8">
            {renderForm()}
            <div className="mt-8 flex justify-between items-center">
                <Button onClick={onBack} variant="outline">
                    Back
                </Button>
                {mode !== 'brainstorm' && (
                    <Button onClick={handleGenerateClick} disabled={isSubmitDisabled()}>
                        Preview Prompt
                    </Button>
                )}
            </div>
        </Card>
    );
};

export default InputScreen;